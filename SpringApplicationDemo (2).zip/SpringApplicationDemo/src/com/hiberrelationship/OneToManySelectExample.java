package com.hiberrelationship;

import java.util.Iterator;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class OneToManySelectExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stubConfiguration cfg = new Configuration();
		  Configuration cfg = new Configuration();  
		  cfg.configure("hibernate.cfg.xml");
		  SessionFactory sf = cfg.buildSessionFactory();
		  Session session = sf.openSession();
		  Vendor v = (Vendor)session.get(Vendor.class, new Integer(2));
		  System.out.println(v.getVendorid());
		  System.out.println(v.getVendorname());
		  Set s = v.getChildren();
		  Iterator it = s.iterator();
		  while(it.hasNext())
		  {
			  Customer ct =(Customer) it.next();
			  System.out.println(ct.getCustid()+ " "+ct.getCustname());
		  }
		  session.close();
		  
		  

	}

}
