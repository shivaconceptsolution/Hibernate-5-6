package com.hiberrelationship;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class OneToManyCode {
public static void main(String args[])
{
	  Configuration cfg = new Configuration();
	  cfg.configure("hibernate.cfg.xml");
	  SessionFactory sf = cfg.buildSessionFactory();
	  Session session = sf.openSession();
	  Transaction tx = session.beginTransaction();
	  Customer c1 = new Customer();
	  c1.setCustid(1003);
	  c1.setCustname("Cust103");
	  Customer c2 = new Customer();
	  c2.setCustid(1004);
	  c2.setCustname("Cust104");
	  Set st = new HashSet();
	  st.add(c1);
	  st.add(c2);
	  Vendor v1 = new Vendor();
	  v1.setVendorid(2);
	  v1.setVendorname("TALLY");
	  v1.setChildren(st);
	  session.save(v1);
	  tx.commit();
	  session.close();
	  
	  
	  
	 
}
}
