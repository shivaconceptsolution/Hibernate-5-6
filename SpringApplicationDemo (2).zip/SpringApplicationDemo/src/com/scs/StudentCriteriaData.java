package com.scs;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;



public class StudentCriteriaData {

	public static void main(String[] args) {
		 Configuration cfg = new Configuration();
		 cfg.configure("hibernate.cfg.xml");
		 SessionFactory sf = cfg.buildSessionFactory();
		 Session session = sf.openSession();
		// Query q = session.createQuery("from Student obj"); //select * from Student
		 Criteria q = session.createCriteria(Student.class);
		// Criterion cq = Restrictions.eq("rno",1);
		// Criterion cq = Restrictions.gt("rno",1);
		// q.add(cq); //merge criterion  to criteria
		 ProjectionList p1=Projections.projectionList();
			p1.add(Projections.property("rno"));
			p1.add(Projections.property("fees"));
		    q.setProjection(p1);
		 List lst = q.list();
		 Iterator st = lst.iterator();
		 while(st.hasNext())
		 {
			// Object o = st.next();
			// System.out.println(o);
			   Object arr[] = (Object[])st.next();
			//  Student o = (Student)st.next();
			  System.out.println(arr[0] + " "+arr[1]);
			// System.out.println(o.getRno() + " "+o.getSname() + " "+o.getBranch()+" "+o.getFees()+ " \n");
		 }
		 session.close();
		 

	}

}
