package com.scs;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
public class EmployeeMain {
	int empid;
	String name;
	String job;
	int sal;
	Configuration cfg;
	SessionFactory sf;
	Session s;
    static  Scanner sc = new Scanner(System.in);
    void accept()
   {
	 
		System.out.println("Enter Empid");
		empid=sc.nextInt();
		System.out.println("Enter empname");
		name=sc.next();
		System.out.println("Enter job");
		job=sc.next();
		System.out.println("Enter salary");
		sal=sc.nextInt();
   }
   void configure()
   {
	    cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		sf = cfg.buildSessionFactory();
		s = sf.openSession();
   }
   void insertData()
   {
	    Transaction tx = s.beginTransaction();
		Employee obj = new Employee();
		obj.setEid(empid);
		obj.setName(name);
		obj.setJob(job);
		obj.setSalary(sal);
		s.save(obj);
		tx.commit();
		
   }
   void selectData()
   {
	     Query q = s.createQuery("from Employee obj"); //select * from Student
		 List lst = q.list();
		 Iterator<Employee> st = lst.iterator();
		 while(st.hasNext())
		 {
			 Employee o = (Employee)st.next();
			 System.out.println(o.getEid() + " "+o.getName() + " "+o.getJob()+" "+o.getSalary()+ " \n");
		 }
		
   }
   void updateData()
   {
	    Transaction tx = s.beginTransaction();

		System.out.println("Enter Empid");
		empid=sc.nextInt();
		Object o = s.get(Employee.class,empid);
		Employee obj = (Employee)o;
		System.out.println("Enter empname");
		name=sc.next();
		System.out.println("Enter job");
		job=sc.next();
		System.out.println("Enter salary");
		sal=sc.nextInt();
		obj.setName(name);
		obj.setJob(job);
		obj.setSalary(sal);
		s.update(obj);
		tx.commit();
		
   }
   void deleteData()
   {
	    Transaction tx = s.beginTransaction();
        System.out.println("Enter Empid");
		empid=sc.nextInt();
		Object o = s.get(Employee.class,empid);
		Employee obj = (Employee)o;
		s.delete(obj);
		tx.commit();
		
   }
   void closeConn()
   {
	   s.close();
   }
	public static void main(String[] args) {
		while(true)
		{
		System.out.println("Press 1 for Data Insertion \n Press 2 for Data Selection \n Press 3 for data updation \n Press 4 for data deletion,Press other for exit");
		char ch = sc.next().charAt(0);
		EmployeeMain obj = new EmployeeMain();
		obj.configure();
		switch(ch)
		{
		case '1':
		obj.accept();
		obj.insertData();
		break;
		case '2':
		obj.selectData();
		break;
		case '3':
		obj.updateData();
		break;
		case '4':
		obj.deleteData();
		break;
		default:
		System.exit(0);
		}
		obj.closeConn();
		}
		
	}

}
